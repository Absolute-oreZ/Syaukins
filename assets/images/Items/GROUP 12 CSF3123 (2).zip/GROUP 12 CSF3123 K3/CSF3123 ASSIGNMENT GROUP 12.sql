CREATE DATABASE socialmedia;

CREATE TABLE user (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    creationDate TIMESTAMP,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(50),
    password VARCHAR(100),
    bio VARCHAR(255),
    profilePhotoURL VARCHAR(255)
);
describe user;
CREATE TABLE photos (
    photoID INT PRIMARY KEY,
    photoURL VARCHAR(255) UNIQUE NOT NULL,
    postID INT NOT NULL,
    creationDate TIMESTAMP,
    size INT(10)
);
describe photos;
CREATE TABLE videos (
    videoID INT PRIMARY KEY,
    videoURL VARCHAR(255) UNIQUE NOT NULL,
    postID INT NOT NULL,
    creationDate TIMESTAMP,
    size INT(10)
);
describe videos;
CREATE TABLE posts (
    postID INT PRIMARY KEY,
    creationDate TIMESTAMP,
    userID INT NOT NULL,
    videoID INT NOT NULL,
    photoID INT NOT NULL,
    caption VARCHAR(200),
    FOREIGN KEY(userID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY(photoID) REFERENCES photos(photoID) ON DELETE CASCADE,
    FOREIGN KEY(videoID) REFERENCES videos(videoID) ON DELETE CASCADE
);
describe posts;
CREATE TABLE comments (
    commentID INT PRIMARY KEY,
    commentText VARCHAR(255),
    userID INT NOT NULL,
    postID INT NOT NULL,
    creationDate TIMESTAMP,
    FOREIGN KEY(postID) REFERENCES posts(postID) ON DELETE CASCADE,
    FOREIGN KEY(userID) REFERENCES user(userID) ON DELETE CASCADE
);
describe comments;
CREATE TABLE likes (
    PRIMARY KEY(userID, postID),
    creationDate TIMESTAMP,
    userID INT NOT NULL,
    postID INT NOT NULL,
    FOREIGN KEY(userID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY(postID) REFERENCES posts(postID) ON DELETE CASCADE
);
describe likes;
CREATE TABLE commentLikes (
    PRIMARY KEY(userID, commentID),
    creationDate TIMESTAMP,
    userID INT NOT NULL,
    commentID INT NOT NULL,
    FOREIGN KEY(userID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY(commentID) REFERENCES comments(commentID) ON DELETE CASCADE
);
describe commentLikes;
CREATE TABLE follows (
    PRIMARY KEY(followerID, followingID),
    creationDate TIMESTAMP,
    followerID INT,
    followingID INT,
    FOREIGN KEY(followerID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY(followingID) REFERENCES user(userID) ON DELETE CASCADE
);
describe follows;
CREATE TABLE hashtags (
    hashtagID INT PRIMARY KEY,
    hashtagName VARCHAR(255) UNIQUE,
    creationDate TIMESTAMP
);
describe hashtags;
CREATE TABLE hashtagFollow (
    PRIMARY KEY(userID, hashtagID),
    creationDate TIMESTAMP,
    userID INT NOT NULL,
    hashtagID INT NOT NULL,
    FOREIGN KEY(userID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY(hashtagID) REFERENCES hashtags(hashtagID) ON DELETE CASCADE
);
describe hashtagFollow;
CREATE TABLE postTags (
    PRIMARY KEY(postID, hashtagID),
    postID INT NOT NULL,
    hashtagID INT NOT NULL,
    FOREIGN KEY(postID) REFERENCES posts(postID) ON DELETE CASCADE,
    FOREIGN KEY(hashtagID) REFERENCES hashtags(hashtagID) ON DELETE CASCADE
);
describe postTags;
CREATE TABLE login (
    loginID INT PRIMARY KEY,
    loginTime TIMESTAMP,
    IP VARCHAR(50),
    userID INT NOT NULL,
    FOREIGN KEY(userID) REFERENCES user(userID) ON DELETE CASCADE
);
describe login;
SET FOREIGN_KEY_CHECKS=0;
SET FOREIGN_KEY_CHECKS=1;
-- Inserting records into the 'user' table
INSERT INTO user (creationDate, username, email, password, bio, profilePhotoURL)
VALUES 
    ('2023-01-15 8:30', 'y_shrl', 'sharul03@email.com', 'ss03Hr1', 'Nature enthusiast and photographer', 'https://pixabay.com/photos/iceland-arctic-fox-fox-white-1979445/'),
    ('2023-01-15 9:45', 'lindaaa', 'theprettyone@email.com', 'kirinn_love', 'I love Food!', 'https://pixabay.com/photos/owl-bird-animal-bird-of-prey-50267/'),
    ('2023-01-15 10:00', 'ezzn_H', '03ezzn@email.com', '3882122', 'Never Stop Gym & Be Unstoppable', 'https://pixabay.com/photos/fox-sleeping-resting-relaxing-red-1284512/'),
    ('2023-01-15 11:15', 'czcz369', '99czman@email.com', 'teslaLihghtning', 'She/Her | Programmer', 'https://pixabay.com/photos/woman-girl-freedom-happy-sun-591576/'),
    ('2023-01-15 12:30', 'is_me_05c', 'pokmey@email.com', 'chingHang', 'in love with @ali,DM is closed', 'https://pixabay.com/photos/iceland-aurora-borealis-2111811/');
   select*from user;

-- Inserting records into the 'photos' table
INSERT INTO photos (photoID,photoURL, postID, creationDate, size)
VALUES 
    (1,'/photos/user1/post1_photo.jpg', 1, '2023-01-15 10:20', 2048),
    (2,'/photos/user2/post2_photo.jpg', 2, '2023-01-15 11:35', 1024),
    (3,'/photos/user3/post3_photo.jpg', 3, '2023-01-15 12:50', 3072),
    (4,'/photos/user4/post4_photo.jpg', 4, '2023-01-15 14:05', 4096),
    (5,'/photos/user5/post5_photo.jpg', 5, '2023-01-15 15:20', 512),
    (6,'/photos/user6/post6_photo.jpg', 6, '2023-01-15 10:20', 2048),
    (7,'/photos/user7/post7_photo.jpg', 7, '2023-01-15 14:05', 4096);
    select*from photos;

-- Inserting records into the 'videos' table
INSERT INTO videos (videoID, videoURL, postID, creationDate, size)
VALUES 
    (1, '/videos/user1/post1_video.mp4', 1, '2023-01-15 10:25', 4096),
    (2, '/videos/user2/post2_video.mp4', 2, '2023-01-15 11:40', 2048),
    (3, '/videos/user3/post3_video.mp4', 3, '2023-01-15 14:10', 8192),
    (4, '/videos/user4/post4_video.mp4', 4, '2023-01-15 15:25', 1024);
    select*from videos;
-- Inserting records into the 'posts' table
INSERT INTO posts (postID, creationDate, userID, videoID, photoID, caption)
VALUES 
    (1, '2023-01-15 10:15', 1, 1, 1, 'Explore the wilderness'),
    (2, '2023-01-15 11:30', 2, 2, 2, 'Delicious recipe'),
    (3, '2023-01-15 12:45', 3, 3, 3, 'Morning workout'),
    (4, '2023-01-15 14:00', 4, 4, 4, 'Coding adventures'),
    (5, '2023-01-15 15:15', 5, 1, 5, 'Adventure awaits'),
    (6, '2023-01-17 10:24', 1, 2, 6, 'Forest are the best!'),
    (7, '2023-01-15 14:00', 4, 3, 7, 'I HATE JAVASCRIPT');
    select*from posts;

-- Inserting records into the 'comments' table
INSERT INTO comments (commentID, commentText, userID, postID, creationDate)
VALUES 
    (1, 'Great shot!', 1, 1, '2023-01-15 10:30'),
    (2, 'Yum!Looks tasty!', 2, 2, '2023-01-15 11:45'),
    (3, 'Keep it up!', 3, 3, '2023-01-15 13:00'),
    (4, 'Impressive code!', 4, 4, '2023-01-15 14:15'),
    (5, 'Incredible journey!', 5, 5, '2023-01-15 15:30'),
    (6, '100%Agree', 2, 6, '2023-01-15 10:30'),
    (7, 'i know right!I hate it too...', 5, 7, '2023-01-15 14:15');
     select*from comments;
    

-- Inserting records into the 'likes' table
INSERT INTO likes (creationDate, userID, postID)
VALUES 
    ('2023-01-15 10:35', 1, 1),
    ('2023-01-15 11:50', 2, 2),
    ('2023-01-15 13:05', 3, 3),
    ('2023-01-15 14:20', 4, 4),
    ('2023-01-15 15:35', 5, 5),
    ('2023-01-15 10:35', 1, 6),
    ('2023-01-15 14:20', 4, 7);
   select*from likes;

-- Inserting records into the 'commentLikes' table
INSERT INTO commentLikes (creationDate, userID, commentID)
VALUES 
    ('2023-01-15 11:15', 1, 1),
    ('2023-01-15 11:20', 2, 2),
    ('2023-01-15 13:25', 3, 3),
    ('2023-01-15 14:40', 4, 4),
    ('2023-01-15 15:55', 5, 5),
    ('2023-01-15 11:15', 2, 6),
    ('2023-01-15 14:40', 5, 7);
    select*from commentLikes;

-- Inserting records into the 'follows' table
INSERT INTO follows (creationDate, followerID, followingID)
VALUES 
    ('2023-01-15 10:40', 1, 1),
    ('2023-01-15 11:55', 2, 2),
    ('2023-01-15 13:10', 3, 3),
    ('2023-01-15 14:25', 4, 4),
    ('2023-01-15 15:40', 5, 5),
    ('2023-01-15 10:40', 2, 3),
    ('2023-01-15 14:25', 5, 1);
    select*from follows;

-- Inserting records into the 'hashtags' table
INSERT INTO hashtags (hashtagID, hashtagName, creationDate)
VALUES 
    (1, 'travel', '2023-01-15 10:55'),
    (2, 'foodie', '2023-01-15 11:00'),
    (3, 'nature', '2023-01-15 13:15'),
    (4, 'fitness', '2023-01-15 14:30'),
    (5, 'technology', '2023-01-15 15:45');
    select*from hashtags;

-- Inserting records into the 'hashtagFollow' table
INSERT INTO hashtagFollow (userID, hashtagID, creationDate)
VALUES 
    (1, 1, '2023-01-15 10:15'),
    (2, 2, '2023-01-15 11:30'),
    (3, 3, '2023-01-15 12:45'),
    (4, 4, '2023-01-15 14:00'),
    (5, 5, '2023-01-15 15:15');
     select*from hashtagFollow;

-- Inserting records into the 'postTags' table
INSERT INTO postTags (postID, hashtagID)
VALUES 
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 1),
    (7, 4);
    select*from postTags;

-- Inserting records into the 'login' table
INSERT INTO login (loginID, loginTime, IP, userID)
VALUES 
    (1, '2023-01-15 11:25', '192.168.0.1', 1),
    (2, '2023-01-15 11:30', '192.168.0.2', 2),
    (3, '2023-01-15 11:35', '192.168.0.3', 3),
    (4, '2023-01-15 11:40', '192.168.0.4', 4),
    (5, '2023-01-15 11:45', '192.168.0.5', 5),
    (6, '2023-01-15 11:40', '192.168.0.4', 3);
    
     select*from login;
    

-- 1. Most Followed Hashtag
SELECT h.hashtagName, COUNT(hf.userID) AS followersCount
FROM hashtagFollow hf
JOIN hashtags h ON hf.hashtagID = h.hashtagID
GROUP BY h.hashtagID
ORDER BY followersCount DESC
LIMIT 1;

-- 2. Most Inactive User
SELECT u.username, MAX(l.loginTime) AS lastLogin
FROM user u
LEFT JOIN login l ON u.userID = l.userID
GROUP BY u.userID
ORDER BY lastLogin ASC
LIMIT 1;

-- 3. Most Likes Posts
SELECT p.postID, p.caption, COUNT(l.userID) AS likesCount
FROM posts p
LEFT JOIN likes l ON p.postID = l.postID
GROUP BY p.postID
ORDER BY likesCount DESC
LIMIT 1;


-- 4. Average post per user
SELECT AVG(postsPerUser) AS avgPostsPerUser
FROM (
	SELECT COUNT(postID) AS postsPerUser
	FROM posts
	GROUP BY userID
) AS userPostCounts;

-- 5.Retrieve posts with a specific hashtag
SELECT posts.postID, posts.caption
FROM posts
JOIN postTags ON posts.postID = postTags.postID
JOIN hashtags ON postTags.hashtagID = hashtags.hashtagID
WHERE hashtags.hashtagName = 'travel';

-- 6.Retrieve posts with their like count and comment count
SELECT posts.postID, posts.caption, COUNT(DISTINCT likes.userID) AS likeCount,
COUNT(DISTINCT comments.commentID) AS commentCount
FROM posts
LEFT JOIN likes ON posts.postID = likes.postID
LEFT JOIN comments ON posts.postID = comments.postID
GROUP BY posts.postID;

-- 7.Retrieve all comments with the usernames of the users who posted them
SELECT comments.commentID, comments.commentText, user.username
FROM comments
JOIN user ON comments.userID = user.userID;



-- 1
-- Before Update
SELECT * FROM posts WHERE postID = 3;
-- Update Statement
UPDATE posts
SET caption = 'New caption for post 3'
WHERE postID = 3;
-- After Update
SELECT * FROM posts WHERE postID = 3;

-- 2
-- Before Update
SELECT * FROM user WHERE userID = 2;
-- Update Statement
UPDATE user
SET email = 'newemail@example.com'
WHERE userID = 2;
-- After Update
SELECT * FROM user WHERE userID = 2;

-- 3
-- Before Update
SELECT * FROM comments WHERE commentID = 5;
-- Update Statement
UPDATE comments
SET commentText = 'Updated comment text'
WHERE commentID = 5;
-- After Update
SELECT * FROM comments WHERE commentID = 5;

-- 1.Before Delete
SELECT * FROM posts WHERE postID = 3;
-- Delete Statement
DELETE FROM posts
WHERE postID = 3;
-- After Delete
SELECT * FROM posts WHERE postID = 3;

-- 2. Before Delete
SELECT * FROM user WHERE userID = 2;
-- Delete Statement
DELETE FROM user
WHERE userID = 2;
-- After Delete
SELECT * FROM user WHERE userID = 2;

-- 3. Before Delete
SELECT * FROM comments WHERE commentID = 5;
-- Delete Statement
DELETE FROM comments
WHERE commentID = 5;
-- After Delete
SELECT * FROM comments WHERE commentID = 5;



